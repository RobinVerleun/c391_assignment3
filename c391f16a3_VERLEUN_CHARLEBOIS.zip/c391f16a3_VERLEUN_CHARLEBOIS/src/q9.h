#ifndef _Q9_H_
#define _Q9_H_

#include "assignment3.h"
#include "queryreader.h"
#include "databasetools.h"

	
#endif