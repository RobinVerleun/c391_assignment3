#ifndef _Q8_H_
#define _Q8_H_

//#include "assignment3.h"
#include "filereader.h"
#include "databasetools.h"

#endif